package unibo.actor22comm;

public enum ProtocolType {
		tcp, udp, coap, mqtt, serial, http, ws
}
