package unibo.actor22.main;

import it.unibo.kactor.IApplMessage;
import it.unibo.radarSystem22.domain.utils.BasicUtils;
import it.unibo.radarSystem22.domain.utils.DomainSystemConfig;
import unibo.actor22.Qak22Context;
import unibo.actor22.Qak22Util;
import unibo.actor22.common.ApplData;
import unibo.actor22.common.LedActor;
import unibo.actor22.common.SonarActor;
import unibo.actor22comm.utils.ColorsOut;
import unibo.actor22comm.utils.CommSystemConfig;
import unibo.actor22comm.utils.CommUtils;

/*
 * Sistema che usa led come attore locale
 */
public class RSActor22onPC {

	private LedActor led;
	private SonarActor sonar;
	private IApplMessage getState;
	private IApplMessage isActive;
	private IApplMessage getDistance;

	public void doJob() {
		ColorsOut.outappl("RSActor22onPC | Start", ColorsOut.BLUE);
		configure();
		BasicUtils.aboutThreads("Before execute - ");
		// BasicUtils.waitTheUser();
		execute();
		terminate();
	}

	protected void configure() {
		DomainSystemConfig.simulation = true;
		DomainSystemConfig.ledGui = true;
		DomainSystemConfig.tracing = false;

		CommSystemConfig.tracing = false;

		DomainSystemConfig.sonarDelay = 200;
		DomainSystemConfig.DLIMIT = 70;

		led = new LedActor(ApplData.ledName);
		sonar = new SonarActor(ApplData.sonarName);

// 		Qak22Context.addActor(led);
// 		Qak22Context.addActor(sonar);
//		otherLeds();
		getState = CommUtils.buildRequest("main", "ask", ApplData.reqLedState, ApplData.ledName);
		isActive = CommUtils.buildRequest("main", "ask", ApplData.reqSonarActive, ApplData.sonarName);
		getDistance = CommUtils.buildRequest("main", "ask", ApplData.reqSonarDistance, ApplData.sonarName);
	}

	protected void otherLeds() {
		// Creo altri Led per verificare che il numero di thread non aumenta
		for (int i = 1; i <= 3; i++) {
			new LedActor(ApplData.ledName + "_" + i);
			Qak22Util.sendAMsg(ApplData.turnOnLed, ApplData.ledName + "_" + i);
			BasicUtils.delay(500);
			Qak22Util.sendAMsg(ApplData.turnOffLed, ApplData.ledName + "_" + i);
		}
	}

	// Accende-spegne il Led due volte
	protected void execute() {
		ColorsOut.outappl("Led | execute", ColorsOut.MAGENTA);
//		for( int i=1; i<=2; i++) {
		Qak22Util.sendAMsg(ApplData.turnOnLed);
		CommUtils.delay(500);
// Inviare una request richiede un attore capace di ricevere la reply	 	    
		Qak22Util.sendAMsg(getState);
		// led.elabMsg(getState); //Richiesta asincrona. Reply inviata a main
		CommUtils.delay(500);
		Qak22Util.sendAMsg(ApplData.turnOffLed);
		// led.elabMsg(ApplData.turnOffLed); //ALTERNATIVA all'uso della utility
		CommUtils.delay(500);
		// Qak22Util.sendAMsg( getState ); //Richiesta asincrona. Reply inviata a main
//		}
		ColorsOut.outappl("Sonar | execute", ColorsOut.MAGENTA);
//		for( int i=1; i<=2; i++) {
		Qak22Util.sendAMsg(ApplData.activateSonar);
		CommUtils.delay(500);
// Inviare una request richiede un attore capace di ricevere la reply	 	    
		// Qak22Util.sendAMsg( isActive );
		// led.elabMsg(getState); //Richiesta asincrona. Reply inviata a main
		CommUtils.delay(500);
		Qak22Util.sendAMsg(getDistance);
		// led.elabMsg(getState); //Richiesta asincrona. Reply inviata a main
		CommUtils.delay(500);
		Qak22Util.sendAMsg(ApplData.deactivateSonar);
		// led.elabMsg(ApplData.turnOffLed); //ALTERNATIVA all'uso della utility
		CommUtils.delay(500);
		// Qak22Util.sendAMsg( isActive ); //Richiesta asincrona. Reply inviata a main
//		}
	}

	public void terminate() {
		BasicUtils.aboutThreads("Before exit - ");
		System.exit(0);
	}

	public static void main(String[] args) {
		BasicUtils.aboutThreads("Before start - ");
		new RSActor22onPC().doJob();
		BasicUtils.aboutThreads("Before end - ");
	}

}

/*
 * Threads: main + Actor22 + LedGui
 */
