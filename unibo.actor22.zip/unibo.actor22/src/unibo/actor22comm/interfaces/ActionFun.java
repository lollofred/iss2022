package unibo.actor22comm.interfaces;

public interface ActionFun {
	void run(String msg);
}
