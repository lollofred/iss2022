package it.unibo.radarSystem22.sprint1;

public interface ActionFunction {
	void run(String msg);
}
