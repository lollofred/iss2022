package unibo.wenvUsage22.actors.demo_robot;
import org.json.JSONObject;
import it.unibo.kactor.IApplMessage;
import unibo.actor22.QakActor22Fsm;
import unibo.actor22comm.interfaces.Interaction2021;
import unibo.actor22comm.interfaces.StateActionFun;
import unibo.actor22comm.utils.ColorsOut;
import unibo.actor22comm.utils.CommUtils;
import unibo.actor22comm.ws.WsConnSysObserver;
import unibo.actor22comm.ws.WsConnection;
import unibo.wenvUsage22.actors.fsm.basic.ActorWithFsmBasic.State;
import unibo.wenvUsage22.common.ApplData;
import unibo.wenvUsage22.common.VRobotMoves;

public  class RobotCleanerDemoFsm extends QakActor22Fsm {  
	private Interaction2021 conn;
	private int numIter = 0;	
	private String wallCollision;
	
	public RobotCleanerDemoFsm(String name) {
		super(name);
 	}
	
  	 
	@Override
	protected void declareTheStates( ) {
		
		
		declareState("start", new StateActionFun() {
			@Override
			public void run(IApplMessage msg) {
				outInfo(""+msg);	
				//Inizializzo la connessione con WEnv
				conn = WsConnection.create("localhost:8091" );				 
				//Aggiungo un observer dei messaggi inviati da WEnv  
				((WsConnection)conn).addObserver(new WsConnSysObserver(getName()));
				VRobotMoves.turnLeft(getName(),conn);
				addTransition( "goingAhead", ApplData.robotCmdId );
				nextState();
			}			
		});
		declareState("goingAhead", new StateActionFun() {
			@Override
			public void run(IApplMessage msg) {
				outInfo("dritto");
				outInfo(""+msg);	
 				VRobotMoves.step(getName(),conn);
				addTransition( "checkResult",  "wsEvent" );
 				nextState();
			}			
		});
		declareState("checkResult", new StateActionFun() {
			@Override
			public void run(IApplMessage msg) {
				outInfo(""+msg);	
				String payload = msg.msgContent().replaceAll("'","");//remove ' ' 
				JSONObject json = new JSONObject(payload);
				outInfo(""+json);
				boolean b = false;
				if( json.has("endmove") )  b = json.getBoolean("endmove");
				if(b) {
					VRobotMoves.step(getName(),conn);
					addTransition( "checkResult",  "wsEvent" );
				}else {
					outInfo("collision?" ); 
					if(json.has("target")) 
						wallCollision = json.get("target").toString();	
					addTransition( "collision",  "wsEvent" );
				}
				nextState();
 			}			
		});
		declareState("collision", new StateActionFun() {
			@Override
			public void run(IApplMessage msg) {
				numIter++;
				outInfo(String.valueOf(numIter) + "-" + wallCollision); 
				if(wallCollision.contains("wallRight"))
            	{
    				outInfo("rotazione");
                	VRobotMoves.turnRightAndStep(getName(), 100, conn);
                	addTransition( "goingAhead",  "wsEvent" ); 
                	nextState();
            	}
				else if(wallCollision.contains("wallLeft")) { 
                	outInfo("rotazione");
                	VRobotMoves.turnLeftAndStep(getName(), 100, conn);
                	addTransition( "goingAhead",  "wsEvent" );
                	nextState();
                }
                else if(wallCollision.contains("wallDown"))
                {
    				outInfo(""+msg);
                	addTransition( "end", ApplData.haltSysCmdId);
                	nextState();
                }
                else
                {
                	outInfo("BYE" );
                	System.exit(0);
                }
                //VRobotMoves.step(getName(), conn );
                //addTransition( "goingAhead",  "wsEvent" );
               // nextState();
  			}			
		});
		
	
		declareState("end", new StateActionFun() {
			@Override
			public void run(IApplMessage msg) {
				outInfo(""+msg);
				outInfo("BYE" );
				System.exit(0);
  			}			
		});
	}
	
	@Override
	protected void setTheInitialState( ) {
		declareAsInitialState( "start" );
	}
	
	protected void doMove(String move) {
		try {
 			conn.forward( move );
		}catch( Exception e) {
			ColorsOut.outerr("robotMOve ERROR:" + e.getMessage() );
		}
	}

 

}
