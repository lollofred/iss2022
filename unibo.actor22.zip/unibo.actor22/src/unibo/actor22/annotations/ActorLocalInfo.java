package unibo.actor22.annotations;

public class ActorLocalInfo {

}
